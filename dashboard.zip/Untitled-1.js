
/*

    ---------                 ------           \                                /     |       _/      |     |\_                 |   ---------------
    |        \               /      \           \                              /      |     _/        |     |  \_               |   |
    |         \             /        \           \                            /       |   _/          |     |    \_             |   |
    |          \           /          \           \                          /        | _/            |     |      \_           |   |
    |           |         /            \           \                        /         |/              |     |        \_         |   ---------------
    |          /         /--------------\           \                      /          |\_             |     |          \_       |                 |
    |         /         /                \           \         /\         /           |  \_           |     |            \_     |                 |
    |        /         /                  \           \       /  \       /            |    \_         |     |              \_   |                 |
    |       /         /                    \           \     /    \     /             |      \_       |     |                \_ |                 |
    --------         /                      \           -----      -----              |        \      |     |                  \|   ---------------

*/
        const visit = 2;
        var firstTime;
        var locations = "Longitude: ";
        var buttons = [];
        var pageName;
        var ipAdd;
        var ycoord;
        var xcoord;
        var response;
        var time;
        var lat;
        var long;

        window.addEventListener('click', (event) => {
            xcoord = event.clientX;
            console.log(xcoord);
            //window.location.href = "sender.php?xcoord=1";
        })

        function sleep(ms) {
            var start = new Date().getTime(), expire = start + ms;
            while (new Date().getTime() < expire) { }
            return;
        }

        window.addEventListener('onload', (event) => {
            ycoord = event.clientY;
            console.log(ycoord);
            
        })

       function hello() {
           var a = 1;
           var b = 2;
           $.ajax({
               type: "POST",
               url: "jbssiteservices.com/ConversionAutomation.py",
               data: { param: a, b }
           }).done(function (o) {
               console.log(o);
           });

            console.log(document.referrer);
            var path = window.location.pathname;
            var page = path.split("/").pop();
            var pageName = page;

            var refer = document.referrer;


            var pgOne = "Page Name: ";

            pgOne = pgOne + pageName.toString() + "  ";

            var okay = "Buttons: "; // + buttons[0]

            var btns = document.querySelectorAll('button');

            btns.forEach(function (item, index) {
                item.addEventListener('click', function () {
                    var gg = item.id;
                    var str = (gg).toString();
                    buttons.push(str);
                    var button = (item.id);

                    fetch("https://ipapi.co/json/")
                        .then(response => response.json())
                        .then((responseJson => {
                            var ips = responseJson.ip;

                            $.get('https://worldtimeapi.org/api/timezone/America/New_York')
                                .done(function (data) {
                                    time = (data.datetime);
                                    time = time.toString();
                                    
                                    $.post("https://sqlphpwebapptry.azurewebsites.net/clicked.php", { ips: ips, button: button, time: time});
                            });

                        }));
                });
            });

            for (var i = 1; i < buttons.length; i++) {
                okay = okay + "," + " " + buttons[i];
            }

            pgOne = pgOne + okay;

            pgOne = pgOne + "Visit Time: ";

            $.post("https://jbssiteservices.com/copy.php", { pg: pgOne });

            $.get('https://worldtimeapi.org/api/timezone/America/New_York')
                .done(function (data) {
                    time = (data.datetime);
                    console.log(time);
                    time = time.slice(11);
                    time = time.substring(0, 2);
                    console.log(time);
                    pgOne = pgOne + time.toString() + "  ";
                });


                //sleep(3500);
            fetch("https://ipapi.co/json/")
                .then(response => response.json())
                .then((responseJson => {
                    var response = responseJson.ip;
                    var addy;
                    var city;
                    var state;
                    var zip;
                    var who;
                    var locations = "Longitude: ";
                    locations = locations + (responseJson.longitude).toString();
                    var july = "   Latitude: ";
                    long = responseJson.longitude;
                    july = july + (responseJson.latitude).toString();
                    lat = responseJson.latitude;
                    locations = locations + july;

                    pgOne = pgOne + " referrer: " + refer;

                    
                    
                    fetch("https://api.geoapify.com/v1/geocode/reverse?lat=" + lat + "&lon=" + long + "&apiKey=76bd43651d0c43578805321eef306773", requestOptions)
                        .then(response => response.json())
                        .then(result => {
                    who = result.features[0].properties.address_line2;
                            console.log(result.features[0].properties);
                            addy = result.features[0].properties.address_line1;
                            city = result.features[0].properties.city;
                            state = result.features[0].properties.state_code;
                            zip = result.features[0].properties.postcode;

                            /*
                            fetch("https://apis.estated.com/v4/property?token=lds0JpWnB29d1aPsaxhdiOzOuh8JFJ&street_address=" + addy + "&city=" + city + "&state=" + state + "&zip_code=" + zip, requestOptions)
                                .then(response => response.json())
                                .then(responseJson => {
                                    console.log(responseJson.data.valuation.value);
                                });*/
                        //This is the one
                       // $.post("https://sqlphpwebapptry.azurewebsites.net/tester.php", { ipAdd: response, locations: who, visit: visit, pgOne: pgOne });
                   

                
                });

                    locations = who;
                    console.log(response);
                    console.log(locations);
                    console.log(visit);
                    console.log(pgOne);

                    
                    
                    //$.post("https://jbssiteservices.com/sender.php", { ipAdd: response, locations: locations, visit: visit, pgOne: pgOne });

                    //$.post("https://sqlphpwebapptry.azurewebsites.net/tester.php", { ipAdd: response, locations: locations, visit: visit, pgOne: pgOne });
                    //$.post("sender.php", { name: response });
                }));

            var requestOptions = {
                method: 'GET',
            };

            
            
            /*    
           fetch("https://apis.estated.com/v4/property?token=lds0JpWnB29d1aPsaxhdiOzOuh8JFJ&street_address=151 Battle Green Dr&city=Rochester&state=NY&zip_code=14624", requestOptions)
               .then(response => response.json())
               .then(responseJson => {
                   console.log(responseJson.data.valuation.value);
               });
            */

       

        // $.post("https://sqlphpwebapptry.azurewebsites.net/insertDoogie.php", { time: time, value: value });
        }
        
    